import express from "express";
import cors from "cors";
import path from "path";
import crypto from "crypto";
import {fileURLToPath} from "url";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import Database from "better-sqlite3";

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const app=express(),PORT=process.env.PORT||3000;
const SECRET=process.env.JWT_SECRET||"dev-only-change-this-secret";
const PF_ID=process.env.PAYFAST_MERCHANT_ID||"";
const PF_KEY=process.env.PAYFAST_MERCHANT_KEY||"";
const PF_PASSPHRASE=process.env.PAYFAST_PASSPHRASE||"";
const PF_SANDBOX=(process.env.PAYFAST_SANDBOX||"true").toLowerCase()==="true";
const BASE_URL=(process.env.APP_BASE_URL||`http://localhost:${PORT}`).replace(/\/$/,"");
const db=new Database("all2go.db");db.pragma("journal_mode=WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'customer',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS merchants(id INTEGER PRIMARY KEY AUTOINCREMENT,owner_id INTEGER NOT NULL,name TEXT NOT NULL,category TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending');
CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT,merchant_id INTEGER NOT NULL,name TEXT NOT NULL,price_cents INTEGER NOT NULL,available INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY AUTOINCREMENT,customer_id INTEGER NOT NULL,merchant_id INTEGER NOT NULL,total_cents INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'placed',payment_status TEXT NOT NULL DEFAULT 'unpaid',delivery_address TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP,payfast_payment_id TEXT);
CREATE TABLE IF NOT EXISTS order_items(id INTEGER PRIMARY KEY AUTOINCREMENT,order_id INTEGER NOT NULL,product_id INTEGER NOT NULL,name TEXT NOT NULL,price_cents INTEGER NOT NULL,quantity INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS payment_events(id INTEGER PRIMARY KEY AUTOINCREMENT,order_id INTEGER,pf_payment_id TEXT,payment_status TEXT,amount_gross TEXT,amount_net TEXT,payload TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
`);

app.use(cors());app.use(express.urlencoded({extended:false}));app.use(express.json({limit:"100kb"}));app.use(express.static(path.join(__dirname,"public")));
const auth=(req,res,next)=>{try{let h=req.headers.authorization||"";if(!h.startsWith("Bearer "))throw 0;req.user=jwt.verify(h.slice(7),SECRET);next()}catch{return res.status(401).json({error:"Login required"})}};
const role=r=>(req,res,next)=>req.user.role===r?next():res.status(403).json({error:"Not authorised"});
const tok=u=>jwt.sign({id:u.id,role:u.role},SECRET,{expiresIn:"7d"});
function signature(data,passphrase=""){
 let s=Object.entries(data).filter(([k,v])=>k!=="signature" && v!=="" && v!==null && v!==undefined)
   .map(([k,v])=>`${k}=${encodeURIComponent(String(v).trim()).replace(/%20/g,"+")}`).join("&");
 if(passphrase)s+=`&passphrase=${encodeURIComponent(passphrase.trim()).replace(/%20/g,"+")}`;
 return crypto.createHash("md5").update(s).digest("hex");
}
const payfastHost=()=>PF_SANDBOX?"sandbox.payfast.co.za":"www.payfast.co.za";
function payfastConfigured(){return !!(PF_ID&&PF_KEY)}

app.get("/api/health",(q,s)=>s.json({ok:true,payment_mode:payfastConfigured()?(PF_SANDBOX?"sandbox":"live"):"not-configured"}));
app.post("/api/register",async(req,res)=>{
 const {name,email,password,role="customer"}=req.body||{};if(!name||!email||!password)return res.status(400).json({error:"Fill in all fields"});
 if(password.length<8)return res.status(400).json({error:"Password must be at least 8 characters"});
 if(!["customer","merchant"].includes(role))return res.status(400).json({error:"Invalid role"});
 const e=email.trim().toLowerCase();if(db.prepare("SELECT id FROM users WHERE email=?").get(e))return res.status(409).json({error:"Email already registered"});
 const h=await bcrypt.hash(password,12),i=db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)").run(name.trim(),e,h,role);
 const u=db.prepare("SELECT id,name,email,role FROM users WHERE id=?").get(i.lastInsertRowid);res.status(201).json({user:u,token:tok(u)});
});
app.post("/api/login",async(req,res)=>{
 const u=db.prepare("SELECT * FROM users WHERE email=?").get((req.body.email||"").trim().toLowerCase());
 if(!u||!(await bcrypt.compare(req.body.password||"",u.password_hash)))return res.status(401).json({error:"Incorrect email or password"});
 res.json({user:{id:u.id,name:u.name,email:u.email,role:u.role},token:tok(u)});
});
app.get("/api/marketplace",(req,res)=>{
 const rows=db.prepare(`SELECT m.id merchant_id,m.name merchant,m.category,p.id product_id,p.name product,p.price_cents
 FROM merchants m LEFT JOIN products p ON p.merchant_id=m.id AND p.available=1 WHERE m.status='approved' ORDER BY m.id,p.id`).all();
 const out={};for(const x of rows){if(!out[x.merchant_id])out[x.merchant_id]={id:x.merchant_id,name:x.merchant,category:x.category,products:[]};if(x.product_id)out[x.merchant_id].products.push({id:x.product_id,name:x.product,price:x.price_cents/100})}res.json(Object.values(out));
});
app.post("/api/merchants",auth,role("merchant"),(req,res)=>{
 const {name,category}=req.body||{};if(!name||!category)return res.status(400).json({error:"Business name and category required"});
 const i=db.prepare("INSERT INTO merchants(owner_id,name,category,status) VALUES(?,?,?,'pending')").run(req.user.id,name.trim(),category);res.status(201).json(db.prepare("SELECT * FROM merchants WHERE id=?").get(i.lastInsertRowid));
});
app.post("/api/products",auth,role("merchant"),(req,res)=>{
 const {merchant_id,name,price}=req.body||{},m=db.prepare("SELECT id FROM merchants WHERE id=? AND owner_id=?").get(merchant_id,req.user.id);
 if(!m||!name||!(Number(price)>=0))return res.status(400).json({error:"Invalid merchant/product"});
 const i=db.prepare("INSERT INTO products(merchant_id,name,price_cents) VALUES(?,?,?)").run(merchant_id,name,Math.round(Number(price)*100));res.status(201).json(db.prepare("SELECT * FROM products WHERE id=?").get(i.lastInsertRowid));
});
app.post("/api/orders",auth,role("customer"),(req,res)=>{
 const {merchant_id,items,delivery_address}=req.body||{};if(!merchant_id||!Array.isArray(items)||!items.length||!delivery_address)return res.status(400).json({error:"Missing order details"});
 let total=0,clean=[];for(const it of items){let p=db.prepare("SELECT id,name,price_cents FROM products WHERE id=? AND merchant_id=? AND available=1").get(it.product_id,merchant_id),q=Number(it.quantity);if(!p||!Number.isInteger(q)||q<1||q>99)return res.status(400).json({error:"Invalid item"});total+=p.price_cents*q;clean.push({p,q})}
 const tx=db.transaction(()=>{let o=db.prepare("INSERT INTO orders(customer_id,merchant_id,total_cents,delivery_address) VALUES(?,?,?,?,?)").run(req.user.id,merchant_id,total,delivery_address.trim());for(const x of clean)db.prepare("INSERT INTO order_items(order_id,product_id,name,price_cents,quantity) VALUES(?,?,?,?,?)").run(o.lastInsertRowid,x.p.id,x.p.name,x.p.price_cents,x.q);return db.prepare("SELECT * FROM orders WHERE id=?").get(o.lastInsertRowid)});res.status(201).json({order:tx()});
});

/* Create a real Payfast hosted-checkout redirect, sandbox by default. */
app.post("/api/orders/:id/payfast",auth,role("customer"),(req,res)=>{
 if(!payfastConfigured())return res.status(503).json({error:"Payfast is not configured. Add your sandbox Merchant ID and Key to environment variables."});
 const o=db.prepare("SELECT o.*,u.name customer,u.email FROM orders o JOIN users u ON u.id=o.customer_id WHERE o.id=? AND o.customer_id=?").get(req.params.id,req.user.id);
 if(!o)return res.status(404).json({error:"Order not found"});
 if(o.payment_status==="paid")return res.status(400).json({error:"Order is already paid"});
 const parts=o.customer.trim().split(/\s+/),first=parts.shift()||"Customer",last=parts.join(" ");
 const data={
   merchant_id:PF_ID,merchant_key:PF_KEY,
   return_url:`${BASE_URL}/payment-success.html?order=${o.id}`,
   cancel_url:`${BASE_URL}/payment-cancel.html?order=${o.id}`,
   notify_url:`${BASE_URL}/api/payfast/itn`,
   name_first:first,name_last:last,email_address:o.email,
   m_payment_id:String(o.id),
   amount:(o.total_cents/100).toFixed(2),
   item_name:`All2Go Order #${o.id}`,
   item_description:"All2Go marketplace order"
 };
 data.signature=signature(data,PF_PASSPHRASE);
 db.prepare("UPDATE orders SET payment_status='pending' WHERE id=?").run(o.id);
 res.json({action:`https://${payfastHost()}/eng/process`,fields:data,sandbox:PF_SANDBOX});
});

/* Payfast ITN. This verifies signature, merchant ID, amount, source and Payfast server confirmation. */
app.post("/api/payfast/itn",async(req,res)=>{
 try{
   const data={...req.body}; const received=data.signature;
   if(!received)return res.status(400).send("Missing signature");
   const expected=signature(data,PF_PASSPHRASE);
   if(!crypto.timingSafeEqual(Buffer.from(received),Buffer.from(expected)))return res.status(400).send("Invalid signature");
   if(String(data.merchant_id)!==String(PF_ID))return res.status(400).send("Invalid merchant");
   const order=db.prepare("SELECT * FROM orders WHERE id=?").get(String(data.m_payment_id));
   if(!order)return res.status(404).send("Unknown order");
   const gross=Number(data.amount_gross);
   if(!Number.isFinite(gross)||Math.abs(gross-order.total_cents/100)>0.001)return res.status(400).send("Amount mismatch");
   if(data.payment_status!=="COMPLETE")return res.status(200).send("Ignored non-complete");
   const host=payfastHost();
   const body=new URLSearchParams();
   for(const [k,v] of Object.entries(data))body.append(k,v);
   const vr=await fetch(`https://${host}/eng/query/validate`,{method:"POST",headers:{"content-type":"application/x-www-form-urlencoded"},body});
   const valid=(await vr.text()).trim()==="VALID";
   if(!valid)return res.status(400).send("Server validation failed");
   db.transaction(()=>{
     db.prepare("INSERT INTO payment_events(order_id,pf_payment_id,payment_status,amount_gross,amount_net,payload) VALUES(?,?,?,?,?,?)")
       .run(order.id,data.pf_payment_id||"",data.payment_status,String(data.amount_gross||""),String(data.amount_net||""),JSON.stringify(data));
     db.prepare("UPDATE orders SET payment_status='paid',status='confirmed',payfast_payment_id=? WHERE id=?").run(data.pf_payment_id||"",order.id);
   })();
   res.status(200).send("OK");
 }catch(e){console.error("ITN error",e);res.status(500).send("ITN error")}
});
app.get("/api/orders",auth,(req,res)=>{
 let rows=req.user.role==="customer"?db.prepare("SELECT o.*,m.name merchant FROM orders o JOIN merchants m ON m.id=o.merchant_id WHERE o.customer_id=? ORDER BY o.id DESC").all(req.user.id):db.prepare("SELECT o.*,m.name merchant,u.name customer FROM orders o JOIN merchants m ON m.id=o.merchant_id JOIN users u ON u.id=o.customer_id WHERE m.owner_id=? ORDER BY o.id DESC").all(req.user.id);res.json(rows);
});
app.get("/api/payment-status/:id",auth,role("customer"),(req,res)=>{const o=db.prepare("SELECT id,payment_status,status FROM orders WHERE id=? AND customer_id=?").get(req.params.id,req.user.id);o?res.json(o):res.status(404).json({error:"Order not found"})});

/* Admin stats */
app.get("/api/admin/stats",auth,role("admin"),(req,res)=>{
 const users=db.prepare("SELECT COUNT(*) n FROM users").get().n,merchants=db.prepare("SELECT COUNT(*) n FROM merchants").get().n,orders=db.prepare("SELECT COUNT(*) n FROM orders").get().n,paid=db.prepare("SELECT COALESCE(SUM(total_cents),0) n FROM orders WHERE payment_status='paid'").get().n;
 res.json({users,merchants,orders,paid_cents:paid,payment_mode:payfastConfigured()?(PF_SANDBOX?"sandbox":"live"):"not-configured"});
});

/* Demo admin/store */
if(!db.prepare("SELECT id FROM users WHERE email='admin@all2go.local'").get()){
 const i=db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'admin')").run("All2Go Admin","admin@all2go.local",bcrypt.hashSync("All2GoAdmin123!",12));
 const m=db.prepare("INSERT INTO merchants(owner_id,name,category,status) VALUES(?,?,?,'approved')").run(i.lastInsertRowid,"All2Go Demo Kitchen","Food");
 [["Burger",79],["Chicken Wrap",65],["Family Pizza",129]].forEach(p=>db.prepare("INSERT INTO products(merchant_id,name,price_cents) VALUES(?,?,?)").run(m.lastInsertRowid,p[0],p[1]*100));
}
app.listen(PORT,"0.0.0.0",()=>console.log(`All2Go v8 running on port ${PORT}`));
